﻿namespace $safeprojectname$.Constraints
{
    public static class Const
    {
        public const string ConfigurationKey = "Configuration";
    }
}
