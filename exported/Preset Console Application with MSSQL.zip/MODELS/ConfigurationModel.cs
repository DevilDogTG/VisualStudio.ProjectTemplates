﻿namespace $safeprojectname$.Models
{
    public class ConfigurationModel : IConfigurationModel
    {
    }
}
