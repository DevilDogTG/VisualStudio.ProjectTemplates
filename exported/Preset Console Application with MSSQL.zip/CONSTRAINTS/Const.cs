﻿namespace $safeprojectname$.Constraints
{
    public static class Const
    {
        public const string ConfigurationFile = "appsettings.json";
        public const string ConfigurationKey = "Configuration";
    }
}
