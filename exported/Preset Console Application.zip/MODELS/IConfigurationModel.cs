﻿namespace $safeprojectname$.Models
{
    public interface IConfigurationModel
    {
    }
}
