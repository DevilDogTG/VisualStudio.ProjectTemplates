﻿namespace $safeprojectname$.Contraints
{
    public static class Const
    {
        public const string ConfigurationKey = "Configuration";
        public const string ConfigurationFile = "appsettings.json";
    }
}
