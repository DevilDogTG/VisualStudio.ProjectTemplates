﻿namespace $safeprojectname$.Models
{
    public class ConfigurationModel : IConfigurationModel
    {
        public bool EnableSwagger { get; set; } = false;
    }
}
