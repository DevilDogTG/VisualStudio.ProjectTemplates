namespace $safeprojectname$.Interfaces.Services;

public interface IAppService
{
    Task RunProcessAsync(CancellationToken cancellationToken);
}