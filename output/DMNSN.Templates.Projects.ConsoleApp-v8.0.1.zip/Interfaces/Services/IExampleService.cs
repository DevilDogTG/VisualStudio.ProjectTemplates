using $safeprojectname$;

namespace $safeprojectname$.Interfaces.Services;

public interface IExampleService
{
    public int Run(ExampleArgs args);
}
