namespace $safeprojectname$.Settings;

public class AppSettings
{
    public string CorrelationKey { get; set; } = "X-Correlation-Id";
}