namespace $safeprojectname$.Interfaces.Services;

public interface IAppService
{
    public int Run(AppArgs args);
}



